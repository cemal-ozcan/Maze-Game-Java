public class Queue<T> {
    public SinglyLinkedList<T> list;

    public Queue() {
        list = new SinglyLinkedList<>();
    }

    // Kuyruğun sonuna ekleme (enqueue)
    public void enqueue(T data) {
        list.addLast(data);
    }

    // Kuyruğun başından çıkarma (dequeue)
    public T dequeue() {
        return list.removeFirst();
    }

    // Kuyruğun başındaki öğeyi göster (çıkarmaz)
    public T peek() {
        return list.get(0);
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }
}
