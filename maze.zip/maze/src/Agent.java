public class Agent {
    public int id;
    public int currentX, currentY;
    public Stack<String> moveHistory;
    public boolean hasReachedGoal;
    public int totalMoves;
    public int backtracks;
    public boolean hasPowerUp;
    public int trapsTriggered;

    public Agent(int id, int startX, int startY) {
        this.id = id;
        this.currentX = startX;
        this.currentY = startY;
        this.moveHistory = new Stack<>();
        this.hasReachedGoal = false;
        this.totalMoves = 0;
        this.backtracks = 0;
        this.hasPowerUp = false;
        this.trapsTriggered = 0;
    }

    public void move(String direction) {
        switch (direction) {
            case "UP":
                currentY--;
                break;
            case "DOWN":
                currentY++;
                break;
            case "LEFT":
                currentX--;
                break;
            case "RIGHT":
                currentX++;
                break;
            default:
                System.out.println("Invalid direction");
                return;
        }
        recordMove(currentX, currentY);
        totalMoves++;
    }

    public void backtrack() {
        if (!moveHistory.isEmpty()) {
            String lastMove = moveHistory.pop();
            String[] coords = lastMove.split(",");
            currentX = Integer.parseInt(coords[0]);
            currentY = Integer.parseInt(coords[1]);
            backtracks++;
            totalMoves++;
        } else {
            System.out.println("No moves to backtrack.");
        }
    }

    public void applyPowerUp() {
        if (hasPowerUp) {
            System.out.println("Power-up applied.");
            hasPowerUp = false;
        } else {
            System.out.println("No power-up available.");
        }
    }

    public void recordMove(int x, int y) {
        moveHistory.push(x + "," + y);
    }

    public String getMoveHistoryAsString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < moveHistory.size(); i++) {
            sb.append(moveHistory.list.get(i));
            if (i != moveHistory.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    public int getId() {
        return id;
    }

    public int getCurrentX() {
        return currentX;
    }

    public int getCurrentY() {
        return currentY;
    }

    public boolean hasReachedGoal() {
        return hasReachedGoal;
    }

    public void setHasReachedGoal(boolean hasReachedGoal) {
        this.hasReachedGoal = hasReachedGoal;
    }

    public int getTotalMoves() {
        return totalMoves;
    }

    public int getBacktracks() {
        return backtracks;
    }

    public boolean hasPowerUp() {
        return hasPowerUp;
    }

    public void setHasPowerUp(boolean hasPowerUp) {
        this.hasPowerUp = hasPowerUp;
    }

    public void usePowerUp() {
        if (hasPowerUp) {
            applyPowerUp();
            System.out.println("Agent " + id + " used a power-up!");
        } else {
            System.out.println("Agent " + id + " has no power-up to use.");
        }
    }

    public void incrementTrapsTriggered() {
        trapsTriggered++;
    }

    public int getTrapsTriggered() {
        return trapsTriggered;
    }
}
