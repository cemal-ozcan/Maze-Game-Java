public class Main {
    public static void main(String[] args) {
        int maxTurns = 50;          // Simülasyon maksimum 50 tur dönecek
        int numAgents = 3;          // 3 ajanla başlat

        GameController controller = new GameController(maxTurns);
        controller.initializeGame(numAgents);
        controller.runSimulation();

        controller.logGameSummaryToFile("simulation_summary.txt");
    }
}
