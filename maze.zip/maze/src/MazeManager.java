import java.util.LinkedList;
import java.util.List;

public class MazeManager {

    // Fields
    private MazeTile[][] grid;
    private int width, height;
    private SinglyLinkedList<Agent> agents;  // Singly linked list for storing agents
    private List<SinglyLinkedList<Integer>> rotatingRows; // Circular linked list for corridors

    // Constructor
    public MazeManager(int width, int height) {
        this.width = width;
        this.height = height;
        this.grid = new MazeTile[width][height];
        this.agents = new SinglyLinkedList<>();
        this.rotatingRows = new LinkedList<>();
        generateMaze();  // Generate the maze when creating the MazeManager
    }

    // Method to generate the maze
    public void generateMaze() {
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                // Randomly generate walls, traps, goal
                char type = getRandomTileType();  // You can decide to implement this function
                grid[i][j] = new MazeTile(i, j, type);
            }
        }
    }

    // Method to randomly generate a tile type
    // (Here, it would be a placeholder as it's not defined in your instructions, but we can handle it)
    private char getRandomTileType() {
        char[] types = {'E', 'W', 'T', 'P', 'G'};  // Empty, Wall, Trap, Power-up, Goal
        return types[(int) (Math.random() * types.length)];
    }

    // Rotate the corridor in a specified row
    public void rotateCorridor(int rowId) {
        // Get the corridor (row) from the grid
        SinglyLinkedList<MazeTile> row = new SinglyLinkedList<>();
        for (int col = 0; col < height; col++) {
            row.addLast(grid[rowId][col]);
        }

        // Perform circular rotation
        MazeTile lastTile = row.removeLast();
        row.addFirst(lastTile);

        // Update the grid with the rotated row
        for (int col = 0; col < height; col++) {
            grid[rowId][col] = row.get(col);
        }
    }

    // Check if the move is valid
    public boolean isValidMove(int fromX, int fromY, String direction) {
        switch (direction) {
            case "UP":
                return fromY > 0 && grid[fromX][fromY - 1].isTraversable();
            case "DOWN":
                return fromY < height - 1 && grid[fromX][fromY + 1].isTraversable();
            case "LEFT":
                return fromX > 0 && grid[fromX - 1][fromY].isTraversable();
            case "RIGHT":
                return fromX < width - 1 && grid[fromX + 1][fromY].isTraversable();
            default:
                return false;
        }
    }

    // Get the tile at specific coordinates
    public MazeTile getTile(int x, int y) {
        return grid[x][y];
    }

    // Update agent's location on the grid
    public void updateAgentLocation(Agent a, int oldX, int oldY) {
        grid[oldX][oldY].setAgent(false); // Ajanı eski konumdan kaldır
        grid[a.getCurrentX()][a.getCurrentY()].setAgent(true); // Ajanı yeni konumda yerleştir
    }


    // Print the current maze snapshot
    public void printMazeSnapshot() {
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                System.out.print(grid[i][j].toString() + " ");
            }
            System.out.println();
        }
    }
}

