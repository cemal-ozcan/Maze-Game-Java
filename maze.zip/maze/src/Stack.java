public class Stack<T> {
    public SinglyLinkedList<T> list;

    public Stack() {
        list = new SinglyLinkedList<>();
    }

    // Eleman ekle (push)
    public void push(T data) {
        list.addFirst(data);
    }

    // Eleman çıkar (pop)
    public T pop() {
        return list.removeFirst();
    }

    // En üstteki elemanı göster (pop etmeden) (peek)
    public T peek() {
        return list.get(0);
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }
}
