public class SinglyLinkedList<T> {
    public static class Node<T> {
        T data;
        Node<T> next;

        // Constructor
        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node<T> head;
    private int size;

    public SinglyLinkedList() {
        head = null;
        size = 0;
    }

    public void addFirst(T data) {
        Node<T> newNode = new Node<>(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void addLast(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    public T removeFirst() {
        if (head == null) return null;
        T data = head.data;
        head = head.next;
        size--;
        return data;
    }

    // Yeni eklenen removeLast() metodu
    public T removeLast() {
        if (head == null) return null; // Liste boşsa
        if (head.next == null) { // Liste tek elemanlıysa
            T data = head.data;
            head = null;
            size--;
            return data;
        }

        // Liste birden fazla eleman içeriyorsa
        Node<T> current = head;
        while (current.next != null && current.next.next != null) {
            current = current.next;
        }
        T data = current.next.data;
        current.next = null;
        size--;
        return data;
    }

    public T get(int index) {
        if (index < 0 || index >= size)
            return null;
        Node<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public Node<T> getHead() {
        return head;
    }
}

