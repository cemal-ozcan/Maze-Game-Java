public class CircularLinkedList<T> {
    public class Node {
        T data;
        Node next;

        Node(T data) {
            this.data = data;
            this.next = this; // başlangıçta kendine döner
        }
    }

    public Node tail;
    public int size;

    public CircularLinkedList() {
        tail = null;
        size = 0;
    }

    public void add(T data) {
        Node newNode = new Node(data);
        if (tail == null) {
            tail = newNode;
        } else {
            newNode.next = tail.next;
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    public T remove() {
        if (tail == null) return null;

        Node head = tail.next;
        if (tail == head) {
            T data = head.data;
            tail = null;
            size--;
            return data;
        } else {
            T data = head.data;
            tail.next = head.next;
            size--;
            return data;
        }
    }

    public T peek() {
        if (tail == null) return null;
        return tail.next.data;
    }

    public void rotate() {
        if (tail != null)
            tail = tail.next;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
