public class GameController {
    private MazeManager maze;
    private TurnManager turns;
    private int maxTurns;
    private int turnCount;

    public GameController(int maxTurns) {
        this.maxTurns = maxTurns;
        this.turnCount = 0;
        this.maze = new MazeManager();
        this.turns = new TurnManager();
    }

    public void initializeGame(int numAgents) {
        maze.generateMaze();
        for (int i = 0; i < numAgents; i++) {
            Agent agent = new Agent("Agent_" + (i + 1), 0, i); // başlangıç noktası
            maze.updateAgentLocation(agent, -1, -1); // ilk konumlandırma
            turns.addAgent(agent); // sıraya ekle
        }
    }

    public void runSimulation() {
        while (turnCount < maxTurns && !turns.allAgentsFinished()) {
            Agent currentAgent = turns.getCurrentAgent();
            processAgentAction(currentAgent);
            turns.logTurnSummary(currentAgent);
            turns.advanceTurn();
            turnCount++;
            maze.printMazeSnapshot();
        }

        printFinalStatistics();
    }

    public void processAgentAction(Agent agent) {
        // Örnek karar mekanizması: rastgele hareket veya bekleme
        int choice = (int) (Math.random() * 3);
        switch (choice) {
            case 0:
                // Move (örnek: sağa git)
                if (maze.isValidMove(agent.getCurrentX(), agent.getCurrentY(), "RIGHT")) {
                    int oldX = agent.getCurrentX();
                    int oldY = agent.getCurrentY();
                    agent.move("RIGHT");
                    maze.updateAgentLocation(agent, oldX, oldY);
                    MazeTile currentTile = maze.getTile(agent.getCurrentX(), agent.getCurrentY());
                    checkTileEffect(agent, currentTile);
                }

                break;
            case 1:
                // Wait
                System.out.println(agent.getId() + " is waiting.");
                break;
            case 2:
                // Power-up kullanımı (örnek mantık)
                if (agent.hasPowerUp()) {
                    agent.usePowerUp();
                    System.out.println(agent.getId() + " used a power-up!");
                }
                break;
        }
    }

    public void checkTileEffect(Agent agent, MazeTile tile) {
        if (tile.getType() == 'T') { // Eğer hücre tuzaksa
            agent.backtrack(); // Geri gitme davranışı
            System.out.println("Agent " + agent.getId() + " fell into a trap and backtracked!");
        } else if (tile.getType() == 'G') { // Eğer hücre hedefse
            agent.setHasReachedGoal(true); // Hedefe ulaşma
            System.out.println(agent.getId() + " reached the goal!");
        }
    }



    public void printFinalStatistics() {
        System.out.println("\n--- Simulation Finished ---");
        System.out.println("Total Turns Played: " + turnCount);

        // TurnManager'dan ajans listesini alıyoruz
        SinglyLinkedList<Agent> agents = TurnManager.getAgentQueue(); // TurnManager'dan ajans kuyruğunu alıyoruz
        SinglyLinkedList.Node<Agent> current = agents.getHead();  // Başlangıç noktası, ilk Node

        // Ajanların istatistiklerini yazdırıyoruz
        while (current != null) {
            Agent agent = current.data;  // 'data' alanına doğrudan erişim
            System.out.println("Agent ID: " + agent.getId() + " - Finished: " + agent.hasReachedGoal());
            System.out.println("Total Moves: " + agent.getTotalMoves());
            System.out.println("Backtracks: " + agent.getBacktracks());
            System.out.println("Power-ups Used: " + (agent.hasPowerUp() ? "Yes" : "No"));
            System.out.println("Traps Triggered: " + agent.getTrapsTriggered());  // Bu metodun Agent sınıfına eklenmiş olması gerek
            System.out.println("-".repeat(30));  // Ayrıcı çizgi

            current = current.next;  // Sonraki Node'a geç
        }
    }




    public void logGameSummaryToFile(String filename) {
        try {
            java.io.PrintWriter writer = new java.io.PrintWriter(filename);
            writer.println("Simulation Summary:");
            writer.println("Total Turns: " + turnCount);
            SinglyLinkedList<Agent> agents = turns.getAgentQueue();
            SinglyLinkedList.Node<Agent> current = agents.getHead();
            while (current != null) {
                Agent a = current.data;
                writer.println(a.getId() + " - Finished: " + a.hasReachedGoal());
                current = current.next;
            }
            writer.close();
            System.out.println("Summary logged to " + filename);
        } catch (Exception e) {
            System.out.println("Error writing summary: " + e.getMessage());
        }
    }
}
