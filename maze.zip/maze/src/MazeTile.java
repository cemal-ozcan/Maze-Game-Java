public class MazeTile {
    private int x, y;  // Tile koordinatları
    private char type; // Hücre tipi ('E', 'W', 'T', 'P', 'G')
    private boolean hasAgent; // Ajan mevcut mu?

    // Constructor
    public MazeTile(int x, int y, char type) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.hasAgent = false; // Başlangıçta ajan yok
    }

    // Geçilebilirlik kontrolü
    public boolean isTraversable() {
        return type == 'E' || type == 'P' || type == 'G';
    }



    // Hücreyi yazdırmak için toString metodu
    @Override
    public String toString() {
        return "Tile(" + x + "," + y + "): " + type;
    }

    // Getter ve Setter'lar
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public char getType() {
        return type;
    }

    public boolean hasAgent() {
        return hasAgent;
    }

    public void setAgent(boolean hasAgent) {
        this.hasAgent = hasAgent;
    }
}
