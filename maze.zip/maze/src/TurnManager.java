public class TurnManager {
    private SinglyLinkedList<Agent> agentQueue;  // Using SinglyLinkedList as the queue
    private int currentRound;

    public TurnManager() {
        agentQueue = new SinglyLinkedList<>();
        currentRound = 0;
    }
    // Yeni ekleyeceğimiz getter metodu
    public SinglyLinkedList<Agent> getAgentQueue() {
        return agentQueue;
    }


    // Rotates the queue to move to the next agent's turn
    public void advanceTurn() {
        if (!agentQueue.isEmpty()) {
            Agent currentAgent = agentQueue.removeFirst();  // Remove the first agent from the list
            agentQueue.addLast(currentAgent);  // Add the agent to the end of the list
            currentRound++;
        }
    }

    // Returns the agent whose turn it currently is
    public Agent getCurrentAgent() {
        if (!agentQueue.isEmpty()) {
            return agentQueue.get(0);  // Get the first agent in the list
        }
        return null;
    }


    // Checks if all agents have finished their turns (i.e., have reached the goal)
    // Checks if all agents have finished their turns (i.e., have reached the goal)
    public boolean allAgentsFinished() {
        SinglyLinkedList.Node<Agent> currentNode = agentQueue.getHead();
        while (currentNode != null) {
            if (!currentNode.data.hasReachedGoal) {  // Access data directly
                return false;  // If any agent has not reached the goal, return false
            }
            currentNode = currentNode.next;  // Move to the next node
        }
        return true;  // All agents finished
    }


    // Logs the summary of an agent's turn
    public void logTurnSummary(Agent agent) {
        System.out.println("Agent " + agent.id + " Summary:");
        System.out.println("  Current Position: (" + agent.currentX + ", " + agent.currentY + ")");
        System.out.println("  Total Moves: " + agent.totalMoves);
        System.out.println("  Backtracks: " + agent.backtracks);
        System.out.println("  Traps Triggered: " + agent.trapsTriggered);
        System.out.println("  Has Reached Goal: " + (agent.hasReachedGoal ? "Yes" : "No"));
        System.out.println("-".repeat(30));  // Print separator line
    }

    // Method to add an agent to the queue (used when initializing the game)
    public void addAgent(Agent agent) {
        agentQueue.addLast(agent);  // Add the agent to the end of the list
    }

    public int getCurrentRound() {
        return currentRound;
    }
}
